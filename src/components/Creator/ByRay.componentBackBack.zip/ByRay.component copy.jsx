import { createRoot } from 'react-dom/client'
import * as THREE from 'three'
import React, { useRef, useState, Suspense, useMemo, useEffect } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Environment, Lightformer, Float, useGLTF, softShadows, BakeShadows, ContactShadows } from '@react-three/drei'
import { LayerMaterial, Base, Depth } from 'lamina'
import { gsap } from "gsap";
import { BufferGeometryUtils } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

import { coordenadas } from './creator.app.jsx';
import { PolyhedronGeometry } from 'three'

softShadows()

function Box(props) {
  // This reference will give us direct access to the mesh
  const mesh = useRef()
  // Set up state for the hovered and active state
  const [hovered, setHover] = useState(false)
  const [active, setActive] = useState(false)
  // Subscribe this component to the render-loop, rotate the mesh every frame
//   useFrame((state, delta) => (mesh.current.rotation.x += 0.01))
  // Return view, these are regular three.js elements expressed in JSX
  return (
    <mesh
      {...props}
      ref={mesh}
      // scale={active ? 4.5 : 4.5}
      receiveShadow
      castShadow
      onClick={(event) => setActive(!active)}
      onPointerOver={(event) => setHover(true)}
      onPointerOut={(event) => setHover(false)}>
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial  />
      {/* <meshStandardMaterial color={hovered ? props.color01 : props.color02} /> */}
    </mesh>
  )
}

const fullArray = (nacimiento, nombres, apellidos, nick) => { 
    // here the array wil be created

  //   const mesh = useRef()
  // // Set up state for the hovered and active state
  // const [hovered, setHover] = useState(false)
  // const [active, setActive] = useState(false)

  // const [nacimiento, setNacimiento] = useState('')
  // const [nombre, setNombre] = useState('')
  // const [apellido, setApellido] = useState('')
  // const [nick, setNick] = useState('')

  let num = 2.0
 
  let num2 = 2

  // Subscribe this component to the render-loop, rotate the mesh every frame
  //Array from Coordenadas 
  // const personalArray = coordenadas(props.nacimiento, props.nombre, props.apellido, props.nick)

  // const personalArray = coordenadas('26101986', 'daniela', 'kelly isunza', 'danny')

  const personalArray = coordenadas(nacimiento, nombres, apellidos, nick)

  //PISOS
    const pisos = [
        0, 3, 7, 12, 16,
        0, 4, 9, 13, 16,
        0, 5, 8, 12, 16,
        0, 3, 6, 10, 16,
        0, 6, 10, 13, 16
    ]
    const positions = [ ];
    let unPlano = [
        // -0.5, 0.5, 0,
        // 0.5, 0.5, 0,
        // -0.5, -0.5, 0,
        // 0.5, -0.5, 0,
    ]
    let array = []

    let escul = []
    const a = 1
    let b = personalArray[6]


for (let i = 0; i < personalArray.length; i++) {
    if(i % 3){
        num = personalArray[i]
    }
     // num = 5

     if(i % 5){
         num2 = personalArray[i]
     }
     if(i % 4){
         b = personalArray[i]
     }
     unPlano = [  
         [-num,  num2,  pisos[i]*9/2], //y 1!=1
         [-num+a,  num2,  pisos[i]*9/2.02], //y y
         [-num, num2+b/1.5,  pisos[i]*9/2], //x 1!=1
         
         [num, num2+b/1.5,  pisos[i]*9/2], //x 1!=1
         [-num+a, num2+b/1.5,  pisos[i]*9/2.02], //x x
         [num+a,  num2,  pisos[i]*9/2.02], //y y
         // [-num, num+b/2,  pisos[i]*9/2], //x 1!=1
     ]

     positions.push(unPlano)



 }
// mark

function prosesator(getPosition){
    for (let i = 0; i < positions.length; i++) {

                array.push(positions[getPosition+0][0]) 
                array.push(positions[getPosition+0][1])
                array.push(positions[getPosition+1][1])

                //
                array.push(positions[getPosition+0][0])
                array.push(positions[getPosition+0][2])
                array.push(positions[getPosition+1][2])

                //
                array.push(positions[getPosition+0][2])
                array.push(positions[getPosition+0][4])
                array.push(positions[getPosition+1][4])

                    //
                array.push(positions[getPosition+0][1])
                array.push(positions[getPosition+0][4])
                array.push(positions[getPosition+1][4])

                ////////
                ///////

                array.push(positions[getPosition+1][0]) 
                array.push(positions[getPosition+1][1])
                array.push(positions[getPosition+0][0])

                //
                array.push(positions[getPosition+1][0])
                array.push(positions[getPosition+1][2])
                array.push(positions[getPosition+0][0])

                //
                array.push(positions[getPosition+1][2])
                array.push(positions[getPosition+1][4])
                array.push(positions[getPosition+0][2])

                    //
                array.push(positions[getPosition+1][1])
                array.push(positions[getPosition+1][4])
                array.push(positions[getPosition+0][1])

                //////////
                //////////
                    /////////
                //////////
                
                
                array.push(positions[getPosition+1][0]) 
                array.push(positions[getPosition+1][1])
                array.push(positions[getPosition+2][1])

                //
                array.push(positions[getPosition+1][0])
                array.push(positions[getPosition+1][2])
                array.push(positions[getPosition+2][2])

                //
                array.push(positions[getPosition+1][2])
                array.push(positions[getPosition+1][4])
                array.push(positions[getPosition+2][4])

                    //
                array.push(positions[getPosition+1][1])
                array.push(positions[getPosition+1][4])
                array.push(positions[getPosition+2][4])

                ////////
                ///////

                array.push(positions[getPosition+2][0]) 
                array.push(positions[getPosition+2][1])
                array.push(positions[getPosition+1][0])

                //
                array.push(positions[getPosition+2][0])
                array.push(positions[getPosition+2][2])
                array.push(positions[getPosition+1][0])

                //
                array.push(positions[getPosition+2][2])
                array.push(positions[getPosition+2][4])
                array.push(positions[getPosition+1][2])

                    //
                array.push(positions[getPosition+2][1])
                array.push(positions[getPosition+2][4])
                array.push(positions[getPosition+1][1])
                


                //////////
                //////////
                    /////////
                //////////
                
                
                array.push(positions[getPosition+2][0]) 
                array.push(positions[getPosition+2][1])
                array.push(positions[getPosition+3][1])

                //
                array.push(positions[getPosition+2][0])
                array.push(positions[getPosition+2][2])
                array.push(positions[getPosition+3][2])

                //
                array.push(positions[getPosition+2][2])
                array.push(positions[getPosition+2][4])
                array.push(positions[getPosition+3][4])

                    //
                array.push(positions[getPosition+2][1])
                array.push(positions[getPosition+2][4])
                array.push(positions[getPosition+3][4])

                ////////
                ///////

                array.push(positions[getPosition+3][0]) 
                array.push(positions[getPosition+3][1])
                array.push(positions[getPosition+2][0])

                //
                array.push(positions[getPosition+3][0])
                array.push(positions[getPosition+3][2])
                array.push(positions[getPosition+2][0])

                //
                array.push(positions[getPosition+3][2])
                array.push(positions[getPosition+3][4])
                array.push(positions[getPosition+2][2])

                    //
                array.push(positions[getPosition+3][1])
                array.push(positions[getPosition+3][4])
                array.push(positions[getPosition+2][1])



                //////////
                //////////
                    /////////
                //////////
                
                
                array.push(positions[getPosition+3][0]) 
                array.push(positions[getPosition+3][1])
                array.push(positions[getPosition+4][1])

                //
                array.push(positions[getPosition+3][0])
                array.push(positions[getPosition+3][2])
                array.push(positions[getPosition+4][2])

                //
                array.push(positions[getPosition+3][2])
                array.push(positions[getPosition+3][4])
                array.push(positions[getPosition+4][4])

                    //
                array.push(positions[getPosition+3][1])
                array.push(positions[getPosition+3][4])
                array.push(positions[getPosition+4][4])

                ////////
                ///////

                array.push(positions[getPosition+4][0]) 
                array.push(positions[getPosition+4][1])
                array.push(positions[getPosition+3][0])

                //
                array.push(positions[getPosition+4][0])
                array.push(positions[getPosition+4][2])
                array.push(positions[getPosition+3][0])

                //
                array.push(positions[getPosition+4][2])
                array.push(positions[getPosition+4][4])
                array.push(positions[getPosition+3][2])

                    //
                array.push(positions[getPosition+4][1])
                array.push(positions[getPosition+4][4])
                array.push(positions[getPosition+3][1])

            
        // }
        
    }

   

}

prosesator(0)
prosesator(5)
prosesator(10)
prosesator(15)
prosesator(20)

// new Float32Array()

for (let i = 0; i < array.length; i++) {
    for (let d = 0; d < array[i].length; d++) {
        escul.push(array[i][d])
        
    }
}



//#Source https://bit.ly/2neWfJ2 
const chunk = (arr, size) =>
  Array.from({ length: Math.ceil(arr.length / size) }, (v, i) =>
    arr.slice(i * size, i * size + size)
  );


//  let sepSculter = chunk(escul, 9216)
 let arrayScult = chunk(escul, 9216)
//  let sepScult = new Float32Array( sepSculter[1] )
//  let arrayScult = new Float32Array( sepSculter[arrayIndex] )

return arrayScult

}

// let sepScult = new Float32Array( sepSculter[props.number] )

let dataToRay = fullArray('26101986', 'daniela', 'kelly isunza', 'danny')


const Ray = (props)=>{
    // This reference will give us direct access to the mesh
  const mesh = useRef()
  // Set up state for the hovered and active state
  const [hovered, setHover] = useState(false)
  const [active, setActive] = useState(false)

  const [nacimiento, setNacimiento] = useState('')
  const [nombre, setNombre] = useState('')
  const [apellido, setApellido] = useState('')
  const [nick, setNick] = useState('')

  let num = 2.0
 
  let num2 = 2

  // Subscribe this component to the render-loop, rotate the mesh every frame
  //Array from Coordenadas 
  // const personalArray = coordenadas(props.nacimiento, props.nombre, props.apellido, props.nick)

  // const personalArray = coordenadas('26101986', 'daniela', 'kelly isunza', 'danny')

  const personalArray = coordenadas('05071977', 'christian', 'valderrama gomez', 'babbu')

  //PISOS
    const pisos = [
        0, 3, 7, 12, 16,
        0, 4, 9, 13, 16,
        0, 5, 8, 12, 16,
        0, 3, 6, 10, 16,
        0, 6, 10, 13, 16
    ]
    const positions = [ ];
    let unPlano = [
        // -0.5, 0.5, 0,
        // 0.5, 0.5, 0,
        // -0.5, -0.5, 0,
        // 0.5, -0.5, 0,
    ]
    let array = []

    let escul = []
    const a = 1
    let b = personalArray[6]

    const vertices = new Float32Array( [
        -1.0, -1.0,  1.0,
        1.0, -1.0,  1.0,
        1.0,  1.0,  1.0,

        1.0,  1.0,  1.0,
        -1.0,  1.0,  1.0,
        -1.0, -1.0,  1.0,

        -2.0, -2.333,  0.0,
        -1.0, 2.0,  0.0,
        -1.0,  2.0,  2.0,

        2.0,  2.0,  2.0,
        -2.0,  2.0,  2.0,
        -2.0, -2.0,  2.0
] );

const verticesOfCube = [
  -1,-1,-1,    1,-1,-1,    1, 1,-1,    -1, 1,-1,
  -1,-1, 1,    1,-1, 1,    1, 1, 1,    -1, 1, 1,
];


for (let i = 0; i < personalArray.length; i++) {
    if(i % 3){
        num = personalArray[i]
    }
     // num = 5

     if(i % 5){
         num2 = personalArray[i]
     }
     if(i % 4){
         b = personalArray[i]
     }
     unPlano = [  
         [-num,  num2,  pisos[i]*9/2], //y 1!=1
         [-num+a,  num2,  pisos[i]*9/2.02], //y y
         [-num, num2+b/1.5,  pisos[i]*9/2], //x 1!=1
         
         [num, num2+b/1.5,  pisos[i]*9/2], //x 1!=1
         [-num+a, num2+b/1.5,  pisos[i]*9/2.02], //x x
         [num+a,  num2,  pisos[i]*9/2.02], //y y
         // [-num, num+b/2,  pisos[i]*9/2], //x 1!=1
     ]

     positions.push(unPlano)



 }
// mark

function prosesator(getPosition){
    for (let i = 0; i < positions.length; i++) {

                array.push(positions[getPosition+0][0]) 
                array.push(positions[getPosition+0][1])
                array.push(positions[getPosition+1][1])

                //
                array.push(positions[getPosition+0][0])
                array.push(positions[getPosition+0][2])
                array.push(positions[getPosition+1][2])

                //
                array.push(positions[getPosition+0][2])
                array.push(positions[getPosition+0][4])
                array.push(positions[getPosition+1][4])

                    //
                array.push(positions[getPosition+0][1])
                array.push(positions[getPosition+0][4])
                array.push(positions[getPosition+1][4])

                ////////
                ///////

                array.push(positions[getPosition+1][0]) 
                array.push(positions[getPosition+1][1])
                array.push(positions[getPosition+0][0])

                //
                array.push(positions[getPosition+1][0])
                array.push(positions[getPosition+1][2])
                array.push(positions[getPosition+0][0])

                //
                array.push(positions[getPosition+1][2])
                array.push(positions[getPosition+1][4])
                array.push(positions[getPosition+0][2])

                    //
                array.push(positions[getPosition+1][1])
                array.push(positions[getPosition+1][4])
                array.push(positions[getPosition+0][1])

                //////////
                //////////
                    /////////
                //////////
                
                
                array.push(positions[getPosition+1][0]) 
                array.push(positions[getPosition+1][1])
                array.push(positions[getPosition+2][1])

                //
                array.push(positions[getPosition+1][0])
                array.push(positions[getPosition+1][2])
                array.push(positions[getPosition+2][2])

                //
                array.push(positions[getPosition+1][2])
                array.push(positions[getPosition+1][4])
                array.push(positions[getPosition+2][4])

                    //
                array.push(positions[getPosition+1][1])
                array.push(positions[getPosition+1][4])
                array.push(positions[getPosition+2][4])

                ////////
                ///////

                array.push(positions[getPosition+2][0]) 
                array.push(positions[getPosition+2][1])
                array.push(positions[getPosition+1][0])

                //
                array.push(positions[getPosition+2][0])
                array.push(positions[getPosition+2][2])
                array.push(positions[getPosition+1][0])

                //
                array.push(positions[getPosition+2][2])
                array.push(positions[getPosition+2][4])
                array.push(positions[getPosition+1][2])

                    //
                array.push(positions[getPosition+2][1])
                array.push(positions[getPosition+2][4])
                array.push(positions[getPosition+1][1])
                


                //////////
                //////////
                    /////////
                //////////
                
                
                array.push(positions[getPosition+2][0]) 
                array.push(positions[getPosition+2][1])
                array.push(positions[getPosition+3][1])

                //
                array.push(positions[getPosition+2][0])
                array.push(positions[getPosition+2][2])
                array.push(positions[getPosition+3][2])

                //
                array.push(positions[getPosition+2][2])
                array.push(positions[getPosition+2][4])
                array.push(positions[getPosition+3][4])

                    //
                array.push(positions[getPosition+2][1])
                array.push(positions[getPosition+2][4])
                array.push(positions[getPosition+3][4])

                ////////
                ///////

                array.push(positions[getPosition+3][0]) 
                array.push(positions[getPosition+3][1])
                array.push(positions[getPosition+2][0])

                //
                array.push(positions[getPosition+3][0])
                array.push(positions[getPosition+3][2])
                array.push(positions[getPosition+2][0])

                //
                array.push(positions[getPosition+3][2])
                array.push(positions[getPosition+3][4])
                array.push(positions[getPosition+2][2])

                    //
                array.push(positions[getPosition+3][1])
                array.push(positions[getPosition+3][4])
                array.push(positions[getPosition+2][1])



                //////////
                //////////
                    /////////
                //////////
                
                
                array.push(positions[getPosition+3][0]) 
                array.push(positions[getPosition+3][1])
                array.push(positions[getPosition+4][1])

                //
                array.push(positions[getPosition+3][0])
                array.push(positions[getPosition+3][2])
                array.push(positions[getPosition+4][2])

                //
                array.push(positions[getPosition+3][2])
                array.push(positions[getPosition+3][4])
                array.push(positions[getPosition+4][4])

                    //
                array.push(positions[getPosition+3][1])
                array.push(positions[getPosition+3][4])
                array.push(positions[getPosition+4][4])

                ////////
                ///////

                array.push(positions[getPosition+4][0]) 
                array.push(positions[getPosition+4][1])
                array.push(positions[getPosition+3][0])

                //
                array.push(positions[getPosition+4][0])
                array.push(positions[getPosition+4][2])
                array.push(positions[getPosition+3][0])

                //
                array.push(positions[getPosition+4][2])
                array.push(positions[getPosition+4][4])
                array.push(positions[getPosition+3][2])

                    //
                array.push(positions[getPosition+4][1])
                array.push(positions[getPosition+4][4])
                array.push(positions[getPosition+3][1])

            
        // }
        
    }

   

}

prosesator(0)
prosesator(5)
prosesator(10)
prosesator(15)
prosesator(20)

// new Float32Array()

for (let i = 0; i < array.length; i++) {
    for (let d = 0; d < array[i].length; d++) {
        escul.push(array[i][d])
        
    }
}



//#Source https://bit.ly/2neWfJ2 
const chunk = (arr, size) =>
  Array.from({ length: Math.ceil(arr.length / size) }, (v, i) =>
    arr.slice(i * size, i * size + size)
  );


 let sepSculter = chunk(escul, 9216)
//  let sepScult = new Float32Array( sepSculter[1] )
 let sepScult = new Float32Array( sepSculter[props.number] )



//  console.log('THE FINAL ARRAY', sepScult)

//  const geom = useMemo(() => {
//   const base = new THREE.BufferGeometry()
//   base.setAttribute('position', sepScult, )
//   base.merge(extra)
//   return base
// }, [extra])


//   useFrame((state, delta) => (mesh.current.rotation.z += 0.001))
  // Return view, these are regular three.js elements expressed in JSX


  return (
    <mesh
        {...props}
        ref={mesh}
        scale={active ? 0.5 : 0.2}
    //   rotation-x={10.5}
    //   rotation-z={0.8}
        // receiveShadow
        castShadow
        onClick={(event) => setActive(!active)}
        onPointerOver={(event) => setHover(true)}
        onPointerOut={(event) => setHover(false)}>
      {/* <boxGeometry args={[1, 1, 1]} /> */}


      <bufferGeometry attach='geometry' onUpdate={self => self.computeVertexNormals()}>
        {/* <bufferAttribute attach='attributes-position' count={9216/3} array={sepScult} itemSize={3} normalized={true} /> */}
        <bufferAttribute attach='attributes-position' count={9216/3} array={props.arrayData} itemSize={3} normalized={true} />
      </bufferGeometry>

  

      <meshStandardMaterial attach='material' side={THREE.DoubleSide}  shininess= {0x111111} color={hovered ? props.color01 : props.color02} />
    </mesh>
  )
}

// createRoot(document.getElementById('root')).render(
//   <Canvas>
//     <ambientLight />
//     <pointLight position={[10, 10, 10]} />
//     <Box position={[-1.2, 0, 0]} />
//     <Box position={[1.2, 0, 0]} />
//   </Canvas>,
// )

 
function Bg(props) {
    const mesh = useRef()
    useFrame((state, delta) => {
      mesh.current.rotation.x = mesh.current.rotation.y = mesh.current.rotation.z += 0.001
    })
    return (
      <mesh ref={mesh} scale={100}>
        <sphereGeometry args={[1, 64, 64]} />
        <LayerMaterial color="white" attach="material" side={THREE.BackSide}>
          <Depth
            colorA="gray"
            colorB={props.colorb}
            alpha={0.2}
            mode="multiply"
            near={0}
            far={300}
            origin={[10, 10, 10]} />

          <Depth
            colorA="#gray"
            colorB={props.colorb}
            alpha={0.2}
            mode="multiply"
            near={0}
            far={300}
            origin={[100, 100, 100]}
          />
        </LayerMaterial>
      </mesh>
    )
  }


const Sculpture = (props) => {
    const group = useRef()
    useFrame((state) => {
        const t = state.clock.getElapsedTime()
        // group.current.rotation.z = -0.2 - (1 + Math.sin(t / 1.5)) / 20
        // group.current.rotation.x = Math.cos(t / 4) / 8
        // group.current.rotation.y = Math.sin(t / 4) / 8
        // group.current.position.y = (1 + Math.sin(t / 1.5)) / 10
        group.current.rotation.y += 0.008

    })
    return(
        <group ref={group} dispose={null} position={[0, -5, 0]}>
            <Box color01={props.color01} color02={props.color02} position={[0, -2, 0]} scale={4.5}/>
            <Box color01={props.color01} color02={props.color02} position={[0, -2.5, -0]} scale={5}/>
            {/* <Ray color01={'hotpink'} color02={props.color01} number={1} position={[1.2, 0, 0]} rotation={[-1.52, 0, 1]}/> */}
            <Ray arrayData={new Float32Array(dataToRay[1])} color01={'hotpink'} color02={props.color02} number={1} position={[1.2, 0, 0]} rotation={[-1.52, 0, 1]}/>
            <Ray arrayData={new Float32Array(dataToRay[0])} color01={'hotpink'} color02={props.color02} number={0} position={[1.2, 0, 0]} rotation={[-1.52, 0, 1.7]}/>

            <Ray arrayData={new Float32Array(dataToRay[2])} color01={'hotpink'} color02={props.color03} number={2} position={[1.2, 0, 0]} rotation={[-1.52, 0, 0.7]}/>
            <Ray arrayData={new Float32Array(dataToRay[3])} color01={'hotpink'} color02={props.color01} number={3} position={[1.2, 0, 0]} rotation={[-1.52, 0, 0.1]}/>
            <Ray arrayData={new Float32Array(dataToRay[4])} color01={'hotpink'} color02={props.color01} number={4} position={[1.2, 0, 0]} rotation={[-1.52, 0, 1.5]}/>
            {/* <Ray arrayData={new Float32Array(dataToRay[5])} color01={'hotpink'} color02={props.color03} number={5} position={[1.2, 0, 0]} rotation={[-1.52, 0, 1.5]}/> */}
        </group>
    )
}

const TwoCubes = (props) => {
    const prop = { base: '#ff4eb8', colorA: '#00ffff', colorB: '#ff00e3' }

    const dirLight = useMemo(()=>{
  
      const light = new THREE.DirectionalLight('white');
      light.castShadow=true;
      //Set up shadow properties for the light
      light.shadow.mapSize.width = 512 // default
      light.shadow.mapSize.height = 512 // default
      light.shadow.camera.near = 0.1 // default
      light.shadow.camera.far = 5000 // default
      light.shadow.camera.top = -100 // default
      light.shadow.camera.right = 100 // default
      light.shadow.camera.left = -100 // default
      light.shadow.camera.bottom = 100 // default
      return light
    
    },[])
  
    const ManageGl = () => {
      const {gl} = useThree()
      // useEffect(()=>{
        gl.localClippingEnabled = true
        gl.antialias = false
        // gl.toneMapping = THREE.ReinhardToneMapping
        // gl.toneMappingExposure = 1.3
        // gl.shadowMap.enabled = true
        // gl.shadowMap.type = THREE.PCFSoftShadowMap
        // gl.setSize(sizes.width, sizes.height)
        // gl.setPixelRatio(Math.min(window.devicePixelRatio, 2))
      // })
    }

    return(
      // fov: 60,
    <Canvas style={{position: 'absolute', top: '0', left: 0, zIndex: -1}}
      shadows
      shadowmap = "true"
      camera={{ position: [0, 0, 15],  near: 0.1, far: 1000 }}
      // frameloop="demand" 
      linear = "true"
      gl={{ preserveDrawingBuffer: true }} 
    >
        
        {/* <ambientLight intensity={0.3} /> */}
    
        {/* <directionalLight position={[0, 5, -18]} color={props.color01} castShadow intensity={10} shadow-camera-far={70} /> */}


        {/* <fog attach="fog" args={['white', 0, 140]} /> */}
        {/* <primitive object={dirLight} position={[30, 0, 30]} /> */}
        {/* <primitive object={dirLight.target} position={[0, 0, 0]}  /> */}
        {/* <ManageGl/> */}
        <ambientLight intensity={0.4} />
        <directionalLight
          castShadow
          // position={[2.5, 8, 5]}
          position={[8, 5, 8]}
          intensity={1}
          shadow-mapSize-width={512}
          shadow-mapSize-height={512}
          shadow-camera-far={50}
          shadow-camera-left={-10}
          shadow-camera-right={10}
          shadow-camera-top={10}
          shadow-camera-bottom={-10}
        />

      {/* <pointLight position={[-10, 0, -20]} color={props.color01} intensity={2.5} /> */}
      <pointLight position={[-10, 0, -20]} color={props.color03} intensity={2.5} />

      <pointLight position={[0, -10, 0]} intensity={1.5} />

      {/* <hemisphereLight skyColor= {0xd8d8d8} groundColor={0x080820} intensity={1} /> */}
      <group position={[0, -7.5, 0]}>
      <mesh receiveShadow castShadow>
        <boxBufferGeometry attach="geometry" args={[4, 1, 1]} />
        <meshStandardMaterial attach="material" />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.5, 0]} receiveShadow>
        <planeBufferGeometry attach="geometry" args={[200, 100]} />
        {/* <shadowMaterial attach="material" transparent opacity={0.4} /> */}
        <meshStandardMaterial attach="material" />
      </mesh>
     
    </group>

      {/* <Suspense fallback={null}> */}
        {/* <BakeShadows /> */}
        <Bg {...prop} colorb={props.color03} />
        {/* <ambientLight /> */}
        {/* <pointLight position={[10, 10, 10]} /> */}
        {/* <Box color01={props.color01} color02={props.color02} position={[-1.2, 0, 0]} /> */}
        {/* <Box color01={props.color01} color02={props.color02} position={[1.2, 0, 0]} /> */}


        
        
        <Sculpture color01={props.color01} color02={props.color02} color03={props.color03}/>

      
        {/* </Suspense> */}
    </Canvas>

        )
  
}

export default TwoCubes